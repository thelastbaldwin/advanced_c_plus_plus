#include <string>

// tried SRCROOT="$SRCROOT" as preprocessor macro and got weird escaping
// I was able to set the macro, but the path wasn't treated like a string
const std::string PROJECT_PATH = "/Users/steveminor/Documents/C++/Advanced_C_Plus_Plus/Assignment 4/Assignment 4/";
