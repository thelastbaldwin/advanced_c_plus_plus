//
//  binary_ostream_iterator.h
//  Assignment 3
//
//  Created by Steve Minor on 5/8/14.
//  Copyright (c) 2014 Steve Minor. All rights reserved.
//

#ifndef __Assignment_3__binary_ostream_iterator__
#define __Assignment_3__binary_ostream_iterator__

#include <iostream>

#endif /* defined(__Assignment_3__binary_ostream_iterator__) */
