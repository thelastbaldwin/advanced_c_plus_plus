//
//  Bitmap.h
//  Assignment 3
//
//  Created by Steve Minor on 5/8/14.
//  Copyright (c) 2014 Steve Minor. All rights reserved.
//

#pragma once

#include <iostream>

namespace BitmapGraphics{
	class Bitmap{
		
	};
}
